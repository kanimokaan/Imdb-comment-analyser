from selenium import webdriver
from selenium.webdriver.common.keys import Keys

g=lambda line: (3.0 if int(line.split("//*//")[0]) >= 9 else (2.0 if int(line.split("--")[0]) >= 7 else (1.0)))

datafile = open("rate_comment_data_top250a.txt","w")

def getRange(st):
    try:
        if int(st) >= 8:
            return 3.0
        elif int(st) >= 4:
            return 2.0
        elif int(st) >= 0:
            return 1.0
    except:
        pass
        #return 1.0

with open("rate_comment_data_top250.txt") as file:
    file.readline()
    for line in file:

        if getRange(line.split("//*//")[0])>0:
            datafile.write(line)
        else:
            print "qqq"



