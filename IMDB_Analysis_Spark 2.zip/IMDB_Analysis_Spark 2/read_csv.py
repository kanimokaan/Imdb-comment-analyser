import csv
import urllib2
from bs4 import BeautifulSoup

datafile = open("rate_comment_data_top250.txt","w")

with open('imdb250Dataset.csv') as file:
    file.readline()
    data = csv.reader(file, delimiter="\t")
    for line in data:
        mid = line[0]

        quote_page = "http://www.imdb.com/title/tt" + mid + "/reviews"

        url = urllib2.urlopen(quote_page).read()

        soup = BeautifulSoup(url)
        review_page = soup.findAll('div', {"id": "main"})[0]

        reviews = review_page.findAll('div', {"class": "lister-item mode-detail imdb-user-review  with-spoiler"})
        print mid,line[1]
        c = 0
        text=""
        #datafile.write(mid+"\n")
        for rv in reviews:
            try:
                # rate
                rate = rv.find('div', {"class": "ipl-ratings-bar"})
                t1 = rate.find("span", {"class": "rating-other-user-rating"})
                t2 = t1.findAll("span")
                user_rate = t2[0].text
                #rate_outof = t2[1].text.strip("/")
                #print user_rate, rate_outof

                # comment
                title = rv.find('div', {"class": "title"}).text

                t1 = rv.find("div", {"class": "content"})
                content = t1.find("div", {"class": "text show-more__control"}).text
                #print title

                try:
                    rate=int(user_rate)
                    datafile.write(user_rate + "//*//" + title + content + "\n")
                except:
                    pass




                #print content,title,user_rate
                #text+=(title+" "+content,user_rate)+"***"
                c += 1

            except:
                #print  "nonon"
                pass


        #print line[1],c

datafile.close()
