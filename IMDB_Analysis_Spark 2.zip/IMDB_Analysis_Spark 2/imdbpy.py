## python 3

from imdb import IMDb
import csv

ia= IMDb()
f = open("top250")
a = f.readlines()

# csv file titile
aa=list()
aa.extend(["ID","title","rate","genre","year","director"])
out=csv.writer(open("imdb250Dataset.csv","w"),delimiter='\t',quoting=csv.QUOTE_NONE)
out.writerow(aa)
del aa[:]

for m in a[0].split(","):
    try:
        id, title = m.split("title:_")
        id = id.split("<Movie id:")[1].split("[")[0]
        title,year=title.strip("_>").split("(")
        year=year.strip(")")
        #print(id,title,year)

        the_matrix = ia.get_movie(id) # 0133093--matrix
        rate=the_matrix.get("rating")
        director = the_matrix.get("director")[0]
        genre=the_matrix.get("genre")[0]

        aa.extend([id,title,rate,genre,year,director])
        out.writerow(aa)
        del aa[:]

    except:
        # print(m)
        pass