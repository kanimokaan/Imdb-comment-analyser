import urllib2
from bs4 import BeautifulSoup
from selenium import webdriver
import time

mv_id=["tt0816692",""]

quote_page="http://www.imdb.com/title/"+mv_id[0]+"/reviews"

url = urllib2.urlopen(quote_page).read()


soup = BeautifulSoup(url)
review_page= soup.findAll('div',{"id":"main"})[0]

reviews=review_page.findAll('div',{"class":"lister-item mode-detail imdb-user-review  with-spoiler"})

c=0
for rv in reviews:
    # rate
    rate = rv.find('div', {"class": "ipl-ratings-bar"})
    t1 = rate.find("span", {"class": "rating-other-user-rating"})
    t2 = t1.findAll("span")
    user_rate = t2[0].text
    rate_outof = t2[1].text.strip("/")
    print user_rate, rate_outof

    # comment
    title = rv.find('div', {"class": "title"}).text

    t1 = rv.find("div", {"class": "content"})
    content = t1.find("div", {"class": "text show-more__control"}).text
    print title
    print content
    print "--------------"
    c+=1

print c